﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string file = "unsorted-list.txt";
            string createFile = "sorted-names-list.txt";

            ReadFiles fl = new ReadFiles();
            GetString str = new GetString();
            Create ctr = new Create();
            ShowData shw = new ShowData();

            fl._fileName = file;
            fl.ReadFile();
            str.BuildString(fl._array);

            string data = str.BuildString(fl._array);
            shw.ShowToScreen(data);
            fl.SortingArray(fl._array);

            shw.ShowToScreen("");
            shw.ShowToScreen("Sorting....");
            shw.ShowToScreen("");

            str.BuildString(fl.SortingArray(fl._array));
            ctr._fileName = createFile;

            string dataSort = str.BuildString(fl.SortingArray(fl._array));
            ctr.CreateFile(dataSort);

            shw.ShowToScreen(dataSort);

            Console.ReadLine();
        }
    }

    interface iRead
    {
        void ReadFile();
    }

    interface iBuildString
    {
        string BuildString(string[] arr);
    }

    public class Create
    {
        public virtual void CreateFile(string data)
        {
            File.WriteAllText(FileName, data);
        }

        public string _fileName;

        private string FileName
        {
            get
            {
                return FileName = _fileName;
            }

            set
            {
                _fileName = value;
            }
        }

    }

    public interface IShowData
    {
        void ShowToScreen();
    }

    public class GetString : iBuildString
    {

        public string BuildString(string[] arr)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var c in arr)
            {
                sb.AppendLine(c);
            }

            return sb.ToString();
        }
    }

    public class ShowData
    {
        public void ShowToScreen(string data)
        {
            Console.WriteLine(data);
        }

    }

    public class DoSorting
    {
        public string[] SortingArray(string[] data)
        {
            Array.Sort<string>(data);

            return data;
        }
    }

    public class ReadFiles : DoSorting, iRead
    {
        public void ReadFile()
        {
            _array = File.ReadAllLines(FileName);
        }

        public string[] _array;

        private string[] array
        {
            get { return array = _array; }
            set { array = value; }
        }

        public string _fileName;

        private string FileName
        {
            get
            {
                return FileName = _fileName;
            }

            set
            {
                _fileName = value;
            }
        }

    }

}

